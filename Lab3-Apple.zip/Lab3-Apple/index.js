const express = require("express");
const app = express();
const port = 3000;
const multer = require('multer');

const upload = multer(); // khởi tạo multer

var bodyParser = require('body-parser')
app.use(express.static("public"));

app.use(express.static("public"))
app.set("view engine", "ejs")
app.set("views", "./views/")
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }))

// parse application/json
app.use(bodyParser.json())
app.use(upload.none()); // sử dụng multer để xử lý multipart/form-data

// Import routes
const routes = require('./routers/index');

// Use routes
app.use('/', routes);

app.listen(port, () => console.log(`Example app listening on portw ${port}!`));