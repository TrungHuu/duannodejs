// file: models/product.js

const mysql = require("mysql");

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "duannodejs",
});

module.exports = {
    // lấy giữ liệu từ table loại
    getCategories: (callback) => {
        let sql = "SELECT id, tenLoai FROM loai";
        db.query(sql, (error, results) => {
            if (error) throw error;
            callback(results);
        });
    },
    // end 
    // lay giu lieu tu san pham 
    getProducts: (callback) => {
        let sql = `SELECT id, tenSP , moTa, urlHinh, gia, giaCu 
                   FROM product`;
        db.query(sql, (error, results) => {
            if (error) throw error;
            callback(results);
        });
    },
    // end 





    // lay giu lieu tu san pham xem theo loại sp
    getProductsbyCa: (categoryId, callback) => {
        let sql = `SELECT id, tenSP , moTa, urlHinh, gia, giaCu 
               FROM product 
               WHERE idLoai = ${categoryId}`;
        db.query(sql, (error, results) => {
            if (error) throw error;
            callback(results);
        });
    },
    // end 



    // su lí xem theo tung chi tiết 
    getProductDetail: (productId, callback) => {
        let sql = `SELECT * FROM product WHERE id = ${productId}`;
        db.query(sql, (error, results) => {
            if (error) throw error;
            callback(results[0]);
        });
    },
    // end 

    // xóa san pham theo id 
    deleteProduct: function (productId, callback) {
        let sql = `DELETE FROM product WHERE id = ${productId}`;
        db.query(sql, (error, result) => {
            if (error) throw error;
            callback(result);
        });
    },
    // 

    // them san pham 
    AddProductc: (tenSP, moTa, urlHinh, gia, giaCu, idLoai, callback) => {
        let sql = `INSERT INTO product (tenSP, moTa, urlHinh, gia, giaCu, idLoai)
                   VALUES("${tenSP}" , "${moTa}","${urlHinh}" ,${gia} , ${giaCu}, ${idLoai})`;
        db.query(sql, (err, result) => {
            if (err) throw err;
            callback(result);
        });
    }




};


