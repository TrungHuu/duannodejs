// file: controllers/productController.js

const productModel = require("../models/product");


// su li chuyen du lieu san pham ra views 
// clien 
exports.home = function (req, res) {
    productModel.getCategories((categories) => {
        productModel.getProducts((products) => {
            res.render("page/home", { loaiSP: categories, listSP: products });
        });
    });
};

// su ly xem sản pham theo loai 
exports.productsByCategory = function (req, res) {
    let categoryId = req.params.categoryId;
    productModel.getCategories((categories) => {
        productModel.getProductsbyCa(categoryId, (products) => {
            res.render("page/home", { loaiSP: categories, listSP: products });
        });
    });
};
// end 

// su ly xem san pham chi tiêt 
exports.productDetail = function (req, res) {
    let productId = req.params.productId;
    productModel.getCategories((categories) => {
        productModel.getProductDetail(productId, (product) => {
            res.render("page/productDetail", { loaiSP: categories, productDetail: product });
        });
    });
};
// end 
// clien 

// admin 

// xóa san pham 
exports.adminDeleteProduct = (req, res) => {
    const productId = req.params.id;

    productModel.deleteProduct(productId, (result) => {
        res.redirect("/admin/list");
    });
};
// end 

// show san pham ra trang quan lí san pham 
exports.adminListProducts = function (req, res) {
    productModel.getCategories((categories) => {
        productModel.getProducts((products) => {
            res.render("admin/list-product", { loaiSP: categories, listSP: products });
        });
    });
};
// end 








// tạo router chuyen sang trang them san pham và chuyền dử liệu loại
exports.addproductsByCategory = function (req, res) {
    productModel.getCategories((categories) => {
        res.render('admin/add-product', {
            listLoai: categories
        });
    });
};
// end 

// sử lý lấy dữ liệu từ from 

exports.addProductc = (req, res) => {
    const tenSP = req.body.tenSP;
    const moTa = req.body.moTa;
    const urlHinh = req.body.urlHinh;
    const gia = req.body.gia
    const giaCu = req.body.giaCu;
    const idLoai = req.body.idLoai

    productModel.AddProductc(tenSP, moTa, urlHinh, gia, giaCu, idLoai, (result) => {
        if (result.affectedRows > 0) { // Nếu sản phẩm được thêm thành công
            res.redirect("/admin/list");
        } else { // Nếu có lỗi xảy ra khi thêm sản phẩm
            res.render("admin/add-product", { message: "Thêm sản phẩm không thành công" });
        }
    });

}
// end 

// edit 


// clien 