// file: routers/index.js

const express = require("express");
const router = express.Router();




const productController = require("../controllers/productController");




router.get("/", productController.home);
// xem theo loai 
router.get("/category/:categoryId", productController.productsByCategory);
// xem theo chi tiet san pham 
router.get("/productDetail/:productId", productController.productDetail);
// show ra trang admin 
router.get("/admin/list", productController.adminListProducts);
// xóa theo id 
router.post('/admin/delete-product/:id', productController.adminDeleteProduct);


// them san pham 
router.get("/admin/add-product", productController.addproductsByCategory);
router.post("/admin/add-product", productController.addProductc);

// sua san pham 




module.exports = router;
